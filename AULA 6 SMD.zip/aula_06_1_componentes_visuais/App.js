import React, {useState} from 'react';
import {Text, View, StyleSheet, TextInput, ActivityIndicator, Button, Image, ImageBackground, ScrollView} from 'react-native';

const MENSAGEM_EMAIL = "Digite o seu e-mail.";
const MENSAGEM_SENHA = "Digite a sua senha.";
const EMAIL = "Aulinha de cria";
const SENHA = "cityslicka";
const CPF = "123.456.789.10";
const CEP = "1 2 3 4 5";
const ENDERECO = " rua do amor";
const SOBRENOME = "LACERJA ARAUJO";
const NOME = "viniciusssss";

const ValidateLogin = async (email, senha, status, activity) => {
    if (email.trim().length === 0) {
        alert(MENSAGEM_EMAIL);
        return
    }

    if (senha.trim().length === 0) {
        alert(MENSAGEM_SENHA);
        return;
    }

    activity(true);

    let usuario = {
        "email": email,
        "password": senha
    };

    await fetch('https://reqres.in/api/login', {
        method: "POST",
        headers: {
            Accept: "application/json",
            'Content-Type': "application/json"
        },
        body: JSON.stringify(usuario)
    }).then(response => {
        if (response.status === 200) {
            response.text().then(function (result) {
                status("Usuário autenticado com sucesso.");
                console.log(result);
            });
        } else {
            status(`Usuário ou senha inválidos => código: ${response.status}`);
        }
        activity(false)
    }).catch(() => status("Não foi possivel executar o login."));
}

export default () => {
    const [user, setUser] = useState('eve.holt@reqres.in')
    const [password, setPassword] = useState('cityslicka')
    const [status, setStatus] = useState('')
    const [activity, setActivity] = useState(false)

    return (
        <View style={Estilos.container}>
            <ImageBackground source={require("./ue2.jfif")}
                     resizeMode="cover" style={Estilos.appImage} imageStyle={{opacity: 0.3}}>
              <Text style={Estilos.paragraph}>oi amores </Text>
              <Image style={Estilos.logo} source={require('./ue.jpg')} />
              <Text style={Estilos.loginLabel}>EMAIL:</Text>
              <TextInput
                  autoCorrect={false}
                  placeholder={MENSAGEM_EMAIL}
                  placeholderTextColor="grey"
                  style={Estilos.textInput}
                  clearButtonMode="always"
                  defaultValue={EMAIL}
                  //mudar o texto quando estou colocando o valor no campo.
                  onChangeText={(value) => setUser(value)}
              />


              
              <Text style={Estilos.loginLabel}>senha:</Text>
              <TextInput
                  autoCorrect={false}
                  placeholder={MENSAGEM_SENHA}
                  placeholderTextColor="grey"
                  secureTextEntry={true}
                  style={Estilos.textInput}
                  clearButtonMode="always"
                  defaultValue={SENHA}
                  onChangeText={(value) => setPassword(value)}
              />

 />
              <Text style={Estilos.loginLabel}>cep:</Text>
              <TextInput
                  autoCorrect={false}
                  placeholder={"me PASSA SEU CEP"}
                  placeholderTextColor="grey"
                  
                  style={Estilos.textInput}
                  clearButtonMode="always"
                  defaultValue={CEP}
                  onChangeText={(value) => setPassword(value)}
              />

               />
               
              <Text style={Estilos.loginLabel}>cpf:</Text>
              <TextInput
                  autoCorrect={false}
                  placeholder={"cpf porra"}
                  placeholderTextColor="grey"
                  style={Estilos.textInput}
                  clearButtonMode="always"
                  defaultValue={CPF}
                  onChangeText={(value) => setPassword(value)}
              />

               <Text style={Estilos.loginLabel}>endereço:</Text>
              <TextInput
                  autoCorrect={false}
                  placeholder={"endereço plis"}
                  placeholderTextColor="grey"
                 
                  style={Estilos.textInput}
                  clearButtonMode="always"
                  defaultValue={ENDERECO}
                  onChangeText={(value) => setPassword(value)}
              />

               <Text style={Estilos.loginLabel}>Sobrenome:</Text>
              <TextInput
                  autoCorrect={false}
                  placeholder={"seu sobrenome plis"}
                  placeholderTextColor="grey"
                 
                  style={Estilos.textInput}
                  clearButtonMode="always"
                  defaultValue={SOBRENOME}
                  onChangeText={(value) => setPassword(value)}
              />

               <Text style={Estilos.loginLabel}>nome:</Text>
              <TextInput
                  autoCorrect={false}
                  placeholder={"COLOQUE SEU NOME LINDO"}
                  placeholderTextColor="grey"
                 
                  style={Estilos.textInput}
                  clearButtonMode="always"
                  defaultValue={NOME}
                  onChangeText={(value) => setPassword(value)}
              />

              <View style={Estilos.button}>
                <Button onPress={() => ValidateLogin(user, password, setStatus, setActivity)} title="OK" />
              </View>
              <View style={{marginTop: 10}}>
                  <ActivityIndicator size="large" animating={activity}/>
              </View>
              <Text style={Estilos.loginLabel}>{status}</Text>
            </ImageBackground>
        </View>
    )
};

const Estilos = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: '#202020'
    },
    paragraph: {
        margin: 24,
        fontSize: 18,
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    loginLabel: {
        color: 'white',
        marginTop: 10,
        fontSize: 15,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    button: {
        fontSize: 15,
        width: 120,
        height: 40,
        marginTop: 20,
        marginHorizontal: 20,
        paddingHorizontal: 10,
        textAlign: 'center',
        alignSelf: 'center'
    },
    textInput: {
        backgroundColor: 'white',
        color: 'black',
        fontSize: 15,
        height: 40,
        width: 250,
        marginTop: 20,
        marginHorizontal: 20,
        paddingHorizontal: 10,
        alignSelf: 'center'
    },
    logo: {
      width: 250,
      height: 100,
      alignSelf: 'center'
    },
    appImage: {
      flex: 1,
      justifyContent: "center",
      backgroundColor: 'black'
    }
});
